# -*- coding: utf-8 -*-
# Project: ml_more_algorithm
# Author: chaoxu create this file
# Time: 2018/4/22
# Company : Maxent
# Email: chao.xu@maxent-inc.com
import time
# from multiprocessing import Pool
#
# def multi_porc(method):
#     def pool_proc(**kw):
#         print(f'Function: {method.__name__}')
#         data = kw.data
#         arg = kw.arg
#         pool = Pool()
#         res = pool.map(method)
#
#         result = method(*args, **kw)
#         return result
#
#     return timed
